clc
clear
close all

%% Grain-size sensitivity

andrade=importdata('Andrade_grain.dat');
burgers=importdata('Burgers_grain.dat');
PL=importdata('PL_grain.dat');
SC=importdata('SC_grain.dat');
Max=importdata('Maxwell_grain.dat');

figure(3)


xlim ([-6 -1])
ylim ([0 80])

plot([1 1]*-4, ylim*.97+1,'LineWidth',310,'Color',[0.9 0.9 0.9]) 
hold on
plot([1 1]*-5.3, ylim*.97+1,'LineWidth',10,'Color',[0.7 0.7 0.7]) 
hold on


plot(andrade(:,1),andrade(:,2)/1e9,'DisplayName','Andrade','LineWidth',4,'Color','b')
hold on
plot(burgers(:,1),burgers(:,2)/1e9,'DisplayName','Andrade','LineWidth',4,'Color','r')
hold on
plot(PL(:,1),PL(:,2)/1e9,'DisplayName','Andrade','LineWidth',4,'Color','m')
hold on
plot(SC(:,1),SC(:,2)/1e9,'DisplayName','Andrade','LineWidth',4,'Color','k')
hold on
plot(Max(:,1),Max(:,2)/1e9,'DisplayName','Maxwell','LineWidth',4,'Color','g')


set(gca,'fontsize',20)
text(-1.5,10,'(e','FontSize',27)

xlabel('$\mathrm{Log_{10}} [d_g/d^{\prime}]$','Interpreter','latex','FontSize',25)
ylabel('Shear Modulus (GPa)','Interpreter','latex','FontSize',25)

xlim ([-6 -1])
ylim ([0 80])

x0=10;
y0=10;
width=500;
height=360;
set(gcf,'units','points','position',[x0,y0,width,height])
xticks([-6 -5 -4 -3 -2  -1])
saveas(gcf,'G_grain_burg','epsc')
%%

figure(2)

xlim ([-6 -1])
ylim ([.01 1000])

plot([1 1]*-4., ylim*.97+17,'LineWidth',285,'Color',[0.9 0.9 0.9]) 
hold on
plot([1 1]*-5.3, ylim*.98+1,'LineWidth',10,'Color',[0.7 0.7 0.7]) 
hold on

plot(andrade(:,1),andrade(:,3),'DisplayName','Andrade','LineWidth',4,'Color','b')
hold on
plot(burgers(:,1),burgers(:,3),'DisplayName','Andrade','LineWidth',4,'Color','r')
hold on
plot(PL(:,1),PL(:,3),'DisplayName','Andrade','LineWidth',4,'Color','m')
hold on
plot(SC(:,1),SC(:,3),'DisplayName','Andrade','LineWidth',4,'Color','k')
hold on
plot(Max(:,1),Max(:,3)/10,'DisplayName','Maxwell','LineWidth',4,'Color','g')
hold on

xlim ([-6 -1])
ylim ([.01 1000])



set(gca,'fontsize',20)
text(-1.6,900,'(f','FontSize',27)

xlabel('$\mathrm{Log_{10}} [d_g/d^{\prime}]$','Interpreter','latex','FontSize',25)
ylabel('Q$_{\mu}$','Interpreter','latex','FontSize',25)


x0=10;
y0=10;
width=500;
height=360;
set(gcf,'units','points','position',[x0,y0,width,height])
xticks([-6 -5 -4 -3 -2 -1])

saveas(gcf,'Q_grain_burg','epsc')

 

%% plot Gs
burgers=importdata('Burgers_period.dat');
andrade=importdata('Andrade_period.dat');
sundberg=importdata('SC_period.dat');
powerlaw=importdata('PL_period.dat');
maxwell=importdata('Maxwell_period.dat');
%%

figure(1)

ylim ([0 80])
semilogx([1 1]*10^-1.9, ylim*.97+1,'LineWidth',140,'Color',[0.9 0.9 0.9]) 
hold on
semilogx([1 1]*10^-2.3, ylim*.97+1,'LineWidth',110,'Color',[0.7 0.7 0.7]) 
hold on

semilogx(10.^andrade(:,1)/3600,andrade(:,2)/1e9,'DisplayName','Andrade','LineWidth',4,'Color','b')
hold on

semilogx(10.^burgers(:,1)/3600,burgers(:,2)/1e9,'DisplayName','Burgers','LineWidth',4,'Color','r')
hold on

semilogx(10.^powerlaw(:,1)/3600,powerlaw(:,2)/1e9,'DisplayName','Power-law','LineWidth',4,'Color','m')
hold on

semilogx(10.^sundberg(:,1)/3600,sundberg(:,2)/1e9,'DisplayName','Sundberg-Cooper','LineWidth',4,'Color','k')
hold on
semilogx(10.^maxwell(:,1)/3600,maxwell(:,2)/1e9,'DisplayName','Maxwell','LineWidth',4,'Color','g')
hold on


plot([1 1]*1/3600, ylim,'LineWidth',2,'Color',[0.5 0.5 0.5]) 
hold on
plot([1 1]*19981/3600, ylim,'LineWidth',2,'Color',[0.5 0.5 0.5]) 
hold on
plot([1 1]*1, ylim,'LineWidth',2,'Color',[0.5 0.5 0.5]) 
hold on
plot([1 1]*12.32, ylim,'LineWidth',2,'Color',[0.5 0.5 0.5]) 
hold on

plot([1 1]*1/3600, ylim,'LineWidth',2,'Color',[0.5 0.5 0.5]) 
hold on


set(gca,'fontsize',20)

xlabel('Period (hr)','Interpreter','latex','FontSize',25)
ylabel('Shear Modulus (GPa)','Interpreter','latex','FontSize',25)
xlim ([1e-6 1e3])
ylim ([0 80])

x0=10;
y0=10;
width=500;
height=360;
set(gcf,'units','points','position',[x0,y0,width,height])

xticks([0.000001 .0001 .01 1 100 ])
text(200,70,'(a','FontSize',27)

hold on

h(1) = plot(NaN,NaN,'g','LineWidth',2);
h(2) = plot(NaN,NaN,'b','LineWidth',2);
h(3) = plot(NaN,NaN,'r','LineWidth',2);
h(4) = plot(NaN,NaN,'m','LineWidth',2);
h(5) = plot(NaN,NaN,'k','LineWidth',2);

lgd=legend(h, 'Maxwell','Andrade','Burgers','Power-law','Sundberg-Cooper','Location','southwest');

set(lgd,'FontSize',15);



%% Plot Qs
figure()

ylim([1e-2 1e3])
loglog([1 1]*10^-1.88, ylim*.85+0.004,'LineWidth',140,'Color',[0.9 0.9 0.9]) 
hold on
loglog([1 1]*10^-2.3, ylim*.85+0.004,'LineWidth',105,'Color',[0.7 0.7 0.7]) 
hold on
    

loglog(10.^andrade(:,1)/3600,10.^(-andrade(:,3)),'DisplayName','Andrade','LineWidth',4,'Color','b')

hold on
loglog(10.^burgers(:,1)/3600,10.^(-burgers(:,3)),'DisplayName','Burgers','LineWidth',4,'Color','r')

hold on

loglog(10.^powerlaw(:,1)/3600,10.^(-powerlaw(:,3)),'DisplayName','Power-law','LineWidth',4,'Color','m')
hold on 

loglog(10.^sundberg(:,1)/3600,10.^(-sundberg(:,3)),'DisplayName','Sundberg-Cooper','LineWidth',4,'Color','k')
hold on

loglog(10.^maxwell(:,1)/3600,10.^(-maxwell(:,3)),'DisplayName','Maxwell','LineWidth',4,'Color','g')
hold on



plot([1 1]*1/3600, ylim,'LineWidth',2,'Color',[0.5 0.5 0.5]) 
hold on
plot([1 1]*19981/3600, ylim,'LineWidth',2,'Color',[0.5 0.5 0.5]) 
hold on
plot([1 1]*1, ylim,'LineWidth',2,'Color',[0.5 0.5 0.5]) 
hold on
plot([1 1]*12.32, ylim,'LineWidth',2,'Color',[0.5 0.5 0.5]) 
hold on

plot([1 1]*1/3600, ylim,'LineWidth',2,'Color',[0.5 0.5 0.5]) 
hold on

set(gca,'fontsize',20)
xlabel('Period (hr)','Interpreter','latex','FontSize',25)
ylabel('$Q_{\mu}$','Interpreter','latex','FontSize',25)
xlim([1e-6 1e3])
ylim([1e-2 1e3])
xticks([.001 .01 .1 1 10 100 1000])

onesec = text(.6/3600,.020,'1 s','FontSize',15);
phobossec = text(19981/3600*.6,.020,'5.55 hr','FontSize',15);
onehr = text(.6,.020,'1 hr','FontSize',15);
sunsec = text(12.32*.65,.020,'12 hr','FontSize',15);
set(onesec,'Rotation',90);
set(phobossec,'Rotation',90);
set(onehr,'Rotation',90);
set(sunsec,'Rotation',90);

x0=10;
y0=10;
width=500;
height=360;
set(gcf,'units','points','position',[x0,y0,width,height])

xticks([0.000001 .0001 .01 1 100])
yticks([0.001 .01 .100 1 10 100 1000])  
text(150,250,'(b','FontSize',27)

saveas(gcf,'Q_T_broader','epsc')

%% temperature profiles (Andrade)

and5_55hr=importdata('Andrade_temperature.dat');

%% temperature profiles (Power law)

PL5_55hr=importdata('PL_temperature.dat');

%% temperature profiles (burgers)

burgers5_55hr=importdata('Burgers_temperature.dat');

%% temperature profiles (S.-C.)

SC5_55hr=importdata('SC_temperature.dat');

%% temperature profiles (Maxwell)

max5_55hr=importdata('Maxwell_temperature.dat');

%% Compaer the rheologies

figure()

xlim([800+270 1400+270])
ylim([0 80])

semilogx([1 1]*1310, ylim*.97+1.2,'LineWidth',139,'Color',[0.9 0.9 0.9]) 
hold on
semilogx([1 1]*1510, ylim*.97+1.2,'LineWidth',46,'Color',[0.7 0.7 0.7]) 
hold on

plot(and5_55hr(:,1)+273,and5_55hr(:,2)/1e9,'DisplayName','Andrade','LineWidth',4,'Color','b')
hold on
plot(burgers5_55hr(:,1)+273,burgers5_55hr(:,2)/1e9,'DisplayName','Burgers','LineWidth',4,'Color','r')
hold on
plot(PL5_55hr(:,1)+273,PL5_55hr(:,2)/1e9,'DisplayName','Power-law','LineWidth',4,'Color','m')
hold on
plot(SC5_55hr(:,1)+273,SC5_55hr(:,2)/1e9,'DisplayName','Sundberg-Cooper','LineWidth',4,'Color','k')
hold on
plot(max5_55hr(:,1)+273,max5_55hr(:,2)/1e9,'DisplayName','Maxwell','LineWidth',4,'Color','g')
hold on
set(gca,'fontsize',20)


xlabel('Temperature (K)','Interpreter','latex','FontSize',25)
ylabel('Shear Modulus (GPa)','Interpreter','latex','FontSize',25)
xlim([600+270 1400+270])
ylim([0 80])

x0=10;
y0=10;
width=500;
height=360;
set(gcf,'units','points','position',[x0,y0,width,height])
text(900,10,'c)','FontSize',27)

saveas(gcf,'diffRhelogy_5_55hr_temp_G','epsc')
%%

figure()

xlim([900+270 1400+270])
ylim([1e-2 1e3])
semilogy([1 1]*1320, ylim*.8+.004,'LineWidth',150,'Color',[0.9 0.9 0.9]) 
hold on
semilogy([1 1]*1520, ylim*.8+.004,'LineWidth',50,'Color',[0.7 0.7 0.7]) 
hold on

semilogy(and5_55hr(:,1)+273,10.^-and5_55hr(:,3),'DisplayName','Andrade','LineWidth',4,'Color','b')
hold on
semilogy(burgers5_55hr(:,1)+273,10.^-burgers5_55hr(:,3),'DisplayName','Burgers','LineWidth',4,'Color','r')

hold on
semilogy(PL5_55hr(:,1)+273,10.^-PL5_55hr(:,3),'DisplayName','Power-law','LineWidth',4,'Color','m')
hold on
semilogy(SC5_55hr(:,1)+273,10.^-SC5_55hr(:,3),'DisplayName','Sundberg-Cooper','LineWidth',4,'Color','k')
hold on

semilogy(max5_55hr(:,1)+273,10.^-max5_55hr(:,3),'DisplayName','Maxwell','LineWidth',4,'Color','g')
hold on
set(gca,'fontsize',20)

xlabel('Temperature (K)','Interpreter','latex','FontSize',25)
ylabel('$Q_{\mu}$','Interpreter','latex','FontSize',25)
xlim([600+270 1400+270])
ylim([1e-2 1e3])
text(900,.050,'d)','FontSize',27)

x0=10;
y0=10;
width=500;
height=360;
set(gcf,'units','points','position',[x0,y0,width,height])
yticks([0.001 .01 .1 1 10 100 1000])

saveas(gcf,'diffRhelogy_5_55hr_temp_Q','epsc')
saveas(gcf,'diffRhelogy_1s_temp_Q','epsc')
